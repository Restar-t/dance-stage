# import cv2
# import mediapipe as mp
# import os
#
# def process_video(input_path: str, output_path: str):
#     """
#     读取输入视频，为每一帧绘制人体骨架，保存到输出视频
#     """
#     # 初始化MediaPipe Pose
#     mp_pose = mp.solutions.pose
#     mp_drawing = mp.solutions.drawing_utils
#     pose = mp_pose.Pose(
#         static_image_mode=False,
#         model_complexity=1,          # 0=轻量,1=标准,2=高精度
#         smooth_landmarks=True,
#         min_detection_confidence=0.5,
#         min_tracking_confidence=0.5
#     )
#
#     # 打开视频
#     cap = cv2.VideoCapture(input_path)
#     if not cap.isOpened():
#         raise Exception("无法打开视频文件")
#
#     # 获取视频属性
#     fps = int(cap.get(cv2.CAP_PROP_FPS))
#     width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
#     height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
#     # 使用 'mp4v' 编码器，通常浏览器兼容
#     fourcc = cv2.VideoWriter_fourcc(*'mp4v')
#     out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
#
#     while cap.isOpened():
#         success, frame = cap.read()
#         if not success:
#             break
#
#         # BGR转RGB
#         frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
#         results = pose.process(frame_rgb)
#
#         # 在原帧上绘制骨架
#         if results.pose_landmarks:
#             mp_drawing.draw_landmarks(
#                 frame,
#                 results.pose_landmarks,
#                 mp_pose.POSE_CONNECTIONS,
#                 mp_drawing.DrawingSpec(color=(0,255,0), thickness=2, circle_radius=2),
#                 mp_drawing.DrawingSpec(color=(0,0,255), thickness=2)
#             )
#
#         out.write(frame)
#
#     cap.release()
#     out.release()
#     pose.close()



import cv2
from mediapipe.python.solutions import pose as mp_pose
from mediapipe.python.solutions import drawing_utils as mp_drawing

def process_video(input_path: str, output_path: str):
    # 降低置信度阈值，提高检测成功率
    pose = mp_pose.Pose(
        static_image_mode=False,
        model_complexity=1,
        smooth_landmarks=True,
        min_detection_confidence=0.3,   # 默认0.5，降低到0.3
        min_tracking_confidence=0.3
    )

    cap = cv2.VideoCapture(input_path)
    if not cap.isOpened():
        raise Exception("无法打开视频文件")

    fps = int(cap.get(cv2.CAP_PROP_FPS))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    # 尝试使用 H.264 编码器，如果不行再改回 mp4v
    fourcc = cv2.VideoWriter_fourcc(*'avc1')  # 优先使用 H.264
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
    if not out.isOpened():
        # 如果 H.264 不支持，回退到 mp4v
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

    frame_count = 0
    detected_count = 0

    while cap.isOpened():
        success, frame = cap.read()
        if not success:
            break

        frame_count += 1
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = pose.process(frame_rgb)

        if results.pose_landmarks:
            detected_count += 1
            # 绘制骨架，线条加粗便于观察
            mp_drawing.draw_landmarks(
                frame,
                results.pose_landmarks,
                mp_pose.POSE_CONNECTIONS,
                mp_drawing.DrawingSpec(color=(0,255,0), thickness=3, circle_radius=3),
                mp_drawing.DrawingSpec(color=(0,0,255), thickness=2)
            )

        out.write(frame)

    cap.release()
    out.release()
    pose.close()

    # 打印检测统计信息
    print(f"总帧数: {frame_count}, 检测到关键点的帧数: {detected_count}")
    if detected_count == 0:
        print("警告: 没有在任何帧中检测到人体关键点，请检查视频内容或调整参数")
    else:
        print(f"检测率: {detected_count/frame_count*100:.1f}%")