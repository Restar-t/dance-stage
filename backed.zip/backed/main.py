from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
import os
import uuid
import shutil

from starlette.middleware.cors import CORSMiddleware

from video_processor import process_video

app = FastAPI(title="视频骨架标记服务")

# 配置 CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:63342"],   # 允许 PyCharm 内置服务器的来源
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="static"), name="static")

# 创建临时目录
UPLOAD_DIR = "uploads"
OUTPUT_DIR = "outputs"
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

@app.post("/process")
async def process_video_endpoint(file: UploadFile = File(...)):
    """
    上传视频，返回处理后的带骨架的视频文件
    """
    # 生成唯一ID，防止文件名冲突
    task_id = str(uuid.uuid4())[:8]
    input_filename = f"{task_id}_{file.filename}"
    input_path = os.path.join(UPLOAD_DIR, input_filename)
    output_filename = f"{task_id}_skeleton.mp4"
    output_path = os.path.join(OUTPUT_DIR, output_filename)

    # 保存上传的文件
    try:
        with open(input_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"文件保存失败: {str(e)}")

    # 处理视频
    try:
        process_video(input_path, output_path)
    except Exception as e:
        # 处理失败后清理上传的文件
        os.remove(input_path)
        raise HTTPException(status_code=500, detail=f"视频处理失败: {str(e)}")

    # 可选：删除上传的原始文件（释放空间）
    os.remove(input_path)

    # 返回处理后的视频文件
    return FileResponse(
        output_path,
        media_type="video/mp4",
        filename=output_filename
    )

@app.get("/")
def root():
    return {"message": "视频骨架标记服务运行中", "usage": "POST /process 上传视频"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)