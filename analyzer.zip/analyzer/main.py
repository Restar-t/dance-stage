# -*- coding: utf-8 -*-
import os
import cv2
import base64
import json
import argparse
from typing import List, Dict, Any, Literal

from dotenv import load_dotenv
from pydantic import BaseModel, Field, ValidationError
from openai import OpenAI


# -------------------------
# 1) 规定输出：只允许 5 个字段
# -------------------------
class SimpleReport(BaseModel):
    dance_style: str = Field(..., description="舞种/风格（中文）。不确定则 '流行舞'")
    strengths: List[str] = Field(..., min_length=1, description="优点（中文要点列表）")
    weaknesses: List[str] = Field(..., min_length=1, description="不足之处（中文要点列表）")
    suggestions: List[str] = Field(..., min_length=2, description="改进建议与推荐练习方法（中文，可执行、可量化）")
    rating: Literal["A", "B", "C", "D"] = Field(..., description="综合评级（A/B/C/D）")


# -------------------------
# 2) 抽帧：把视频变成多张图片（base64）
# -------------------------
def extract_frames(
    video_path: str,
    sample_fps: float = 2.0,
    max_frames: int = 16,
    resize_width: int = 640,
    jpeg_quality: int = 75,
) -> List[Dict[str, Any]]:
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"无法打开视频: {video_path}")

    native_fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    frame_interval = int(round(native_fps / sample_fps))
    frame_interval = max(frame_interval, 1)

    frames: List[Dict[str, Any]] = []
    idx = 0
    picked = 0

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        if idx % frame_interval == 0:
            h, w = frame.shape[:2]
            if w > resize_width:
                new_h = int(h * (resize_width / w))
                frame = cv2.resize(frame, (resize_width, new_h), interpolation=cv2.INTER_AREA)

            ok2, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), jpeg_quality])
            if ok2:
                b64 = base64.b64encode(buf.tobytes()).decode("utf-8")
                t = idx / native_fps
                frames.append({"time": round(t, 3), "b64_jpg": b64})
                picked += 1
                if picked >= max_frames:
                    break

        idx += 1

    cap.release()

    if not frames:
        raise RuntimeError("抽帧结果为空，请检查视频路径/格式是否正确。")
    return frames


# -------------------------
# 3) 提示词：强制只输出 JSON（5 字段，中文）
# -------------------------
def build_prompt(frame_times: List[float]) -> str:
    return f"""
你是一名专业舞蹈老师。你将收到同一段舞蹈视频的多帧画面（按时间顺序抽帧，画面可能包含骨架/关节点标注）。

请用中文分析舞蹈，并且【只输出一个合法 JSON】（不要输出任何额外文字、不要 Markdown、不要解释）。

JSON 必须严格且仅包含以下 5 个顶层字段（字段名必须完全一致，不允许新增/缺失字段）：
1) "dance_style": 字符串。舞种/风格。考虑融合舞种。无法确定则填 "流行舞"。
2) "strengths": 字符串数组。优点，用一段话来描述，要求评价真挚像老师指导学生，文字更加细腻，保持专业度的同时去除ai的感觉，尽量具体到身体控制/节奏/重心/动作幅度/线条等。
3) "weaknesses": 字符串数组。不足之处，用一段话来描述，要求评价真挚像老师指导学生，文字更加细腻，保持专业度的同时去除ai的感觉，指出清晰可改进点（例如重心不稳、发力路径、动作干净度、延展不足等）。
4) "suggestions": 字符串数组。改进建议与推荐怎么练习，2-3条；必须可执行、可量化（例如“每天 15 分钟，做××训练，3 组，每组 8 次，注意××”）。
5) "rating": 字符串，只能是 "A"、"B"、"C"、"D" 之一。

评分参考（只用于你内部判断，不要写在输出里）：
A=舞感与技术都好；B=整体不错但有明显短板；C=基础不足需系统���练；D=节奏/控制/动作完成度明显问题需从基础重练。

抽帧时间戳（秒）如下，仅供你参考动作变化节奏：
{frame_times}
""".strip()


def extract_json_text(s: str) -> str:
    """兜底：如果模型在 JSON 前后夹了别的文字，尝试截取最外层 JSON。"""
    if not s:
        return s
    s = s.strip()
    i = s.find("{")
    j = s.rfind("}")
    if i != -1 and j != -1 and j > i:
        return s[i : j + 1]
    return s


# -------------------------
# 4) 调用硅基流动（OpenAI 兼容）多模态
# -------------------------
def call_siliconflow_multimodal(
    model: str,
    prompt: str,
    frames: List[Dict[str, Any]],
    base_url: str,
    api_key: str,
) -> str:
    client = OpenAI(base_url=base_url, api_key=api_key)

    user_content: List[Dict[str, Any]] = [{"type": "text", "text": prompt}]
    for f in frames:
        user_content.append(
            {
                "type": "image_url",
                "image_url": {"url": f"data:image/jpeg;base64,{f['b64_jpg']}"},
            }
        )

    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": "你必须严格只输出合法 JSON，不要输出任何其他字符。"},
            {"role": "user", "content": user_content},
        ],
        temperature=0.2,
    )

    choice0 = resp.choices[0]
    finish_reason = getattr(choice0, "finish_reason", None)
    content = choice0.message.content or ""

    if not content.strip():
        raise RuntimeError(f"模型返回空内容。finish_reason={finish_reason}")

    return content


# -------------------------
# 5) 端到端：视频 -> JSON 报告
# -------------------------
def analyze_video(video_path: str) -> SimpleReport:
    load_dotenv(dotenv_path=".env")

    base_url = os.getenv("SILICONFLOW_BASE_URL", "https://api.siliconflow.cn/v1")
    api_key = os.getenv("SILICONFLOW_API_KEY")
    if not api_key:
        raise RuntimeError("请在 .env 或系统环境变量中设置 SILICONFLOW_API_KEY")

    # 你指定的硅基流动真实模型 id
    model = "Pro/Qwen/Qwen2.5-VL-7B-Instruct"

    frames = extract_frames(
        video_path=video_path,
        sample_fps=2.0,
        max_frames=16,
        resize_width=640,
        jpeg_quality=75,
    )
    frame_times = [f["time"] for f in frames]
    prompt = build_prompt(frame_times)

    raw = call_siliconflow_multimodal(
        model=model,
        prompt=prompt,
        frames=frames,
        base_url=base_url,
        api_key=api_key,
    )

    raw = extract_json_text(raw)

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"模型未返回合法 JSON。原始输出如下：\n{raw}") from e

    try:
        return SimpleReport.model_validate(data)
    except ValidationError as e:
        raise RuntimeError(
            "JSON 结构不符合规定（必须仅 5 个字段且类型正确）。\n"
            f"原始 JSON：\n{json.dumps(data, ensure_ascii=False, indent=2)}\n\n校验错误：\n{e}"
        ) from e


# -------------------------
# 6) 命令行入口
# -------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Use SiliconFlow multimodal LLM to analyze dance video via frame sampling."
    )
    parser.add_argument(
        "video",
        nargs="?",
        default="C:/Users/ruanyuantao/Desktop/python/analyzer/1.mp4",
        help="Path to input video (optional).",
    )
    args = parser.parse_args()

    report = analyze_video(args.video)
    print(report.model_dump_json(indent=2, ensure_ascii=False))